import type { LaunchVehicle, MissionStatus, VehicleStatus } from "../types";

const parisDate = new Intl.DateTimeFormat("fr-FR", {
  dateStyle: "medium",
  timeStyle: "short",
  timeZone: "Europe/Paris",
});

export function formatLaunchWindow(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return "fenêtre inconnue";
  }
  return `${parisDate.format(date)} (heure de Paris)`;
}

export function statusLabel(status: VehicleStatus): string {
  switch (status) {
    case "ready":
      return "Prêt";
    case "maintenance":
      return "Maintenance";
    case "assigned":
      return "Assigné";
    case "grounded":
      return "Cloué au sol";
  }
}

export function missionStatusLabel(status: MissionStatus): string {
  switch (status) {
    case "draft":
      return "Brouillon";
    case "scheduled":
      return "Planifiée";
    case "countdown":
      return "Compte à rebours";
    case "liftoff":
      return "Décollage";
    case "ascent":
      return "Ascension";
    case "orbit":
      return "Orbite";
    case "docking":
      return "Amarrage";
    case "completed":
      return "Terminée";
    case "aborted":
      return "Interrompue";
  }
}

export function vehicleMetric(vehicle: LaunchVehicle): { label: string; value: string } {
  switch (vehicle.kind) {
    case "reusable-launcher":
      return {
        label: "Vols effectués",
        value: `${vehicle.flightsCompleted} vol${vehicle.flightsCompleted > 1 ? "s" : ""}`,
      };
    case "heavy-launcher":
      return {
        label: "Charge utile max",
        value: `${vehicle.maxPayloadKg.toLocaleString("fr-FR")} kg`,
      };
    case "cargo-vehicle":
      return {
        label: "Port d'amarrage",
        value: `Port ${vehicle.dockingPort}`,
      };
  }
}

export function vehicleKindLabel(vehicle: LaunchVehicle): string {
  switch (vehicle.kind) {
    case "reusable-launcher":
      return "Lanceur réutilisable";
    case "heavy-launcher":
      return "Lanceur lourd";
    case "cargo-vehicle":
      return "Véhicule cargo";
  }
}
