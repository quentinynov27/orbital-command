import type { MissionStatus, VehicleStatus } from "../types";
import { missionStatusLabel, statusLabel } from "../lib/format";

const vehicleTone: Record<VehicleStatus, string> = {
  ready: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30",
  maintenance: "bg-amber-500/15 text-amber-200 ring-amber-400/30",
  assigned: "bg-sky-500/15 text-sky-300 ring-sky-400/30",
  grounded: "bg-slate-500/20 text-slate-300 ring-slate-400/30",
};

const missionTone: Record<MissionStatus, string> = {
  draft: "bg-slate-500/20 text-slate-300 ring-slate-400/30",
  scheduled: "bg-sky-500/15 text-sky-300 ring-sky-400/30",
  countdown: "bg-amber-500/15 text-amber-200 ring-amber-400/30",
  liftoff: "bg-orange-500/15 text-orange-200 ring-orange-400/30",
  ascent: "bg-orange-500/15 text-orange-200 ring-orange-400/30",
  orbit: "bg-cyan-500/15 text-cyan-200 ring-cyan-400/30",
  docking: "bg-violet-500/15 text-violet-200 ring-violet-400/30",
  completed: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/30",
  aborted: "bg-rose-500/15 text-rose-200 ring-rose-400/30",
};

export function StatusBadge({ status }: { status: VehicleStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ${vehicleTone[status]}`}
    >
      {statusLabel(status)}
    </span>
  );
}

export function MissionBadge({ status }: { status: MissionStatus }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ${missionTone[status]}`}
    >
      {missionStatusLabel(status)}
    </span>
  );
}
