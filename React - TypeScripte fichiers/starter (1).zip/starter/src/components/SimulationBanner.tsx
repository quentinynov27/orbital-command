export function SimulationBanner() {
  return (
    <p
      role="status"
      className="border-b border-amber-500/30 bg-amber-500/10 px-4 py-2 text-center text-xs font-medium tracking-wide text-amber-200"
    >
      SIMULATION PÉDAGOGIQUE — AstraForge Aerospace · Orbital Command · données fictives ·
      toutes les unités sont affichées
    </p>
  );
}
