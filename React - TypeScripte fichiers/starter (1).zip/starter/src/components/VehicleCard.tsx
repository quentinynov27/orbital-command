import type { LaunchVehicle } from "../types";
import { vehicleKindLabel, vehicleMetric } from "../lib/format";
import { StatusBadge } from "./StatusBadge";
import { Metric } from "./Metric";

export function VehicleCard({ vehicle }: { vehicle: LaunchVehicle }) {
  const metric = vehicleMetric(vehicle);

  return (
    <article className="flex flex-col gap-4 rounded-2xl border border-slate-800 bg-slate-900/70 p-5">
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-cyan-400">
            {vehicle.model} · {vehicleKindLabel(vehicle)}
          </p>
          <h2 className="mt-1 text-xl font-semibold text-white">{vehicle.name}</h2>
        </div>
        <StatusBadge status={vehicle.status} />
      </header>
      <Metric label={metric.label} value={metric.value} />
    </article>
  );
}
