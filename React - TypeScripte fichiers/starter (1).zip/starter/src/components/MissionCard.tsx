import type { Mission } from "../types";
import { findVehicle } from "../data";
import { formatLaunchWindow } from "../lib/format";
import { MissionBadge } from "./StatusBadge";

export function MissionCard({ mission }: { mission: Mission }) {
  const vehicle = findVehicle(mission.vehicleId);

  return (
    <article className="rounded-2xl border border-slate-800 bg-slate-900/70 p-5">
      <header className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.18em] text-cyan-400">Mission</p>
          <h2 className="mt-1 text-xl font-semibold text-white">{mission.codeName}</h2>
        </div>
        <MissionBadge status={mission.status} />
      </header>
      <p className="mt-3 text-sm text-slate-300">{mission.objective}</p>
      <dl className="mt-4 grid gap-2 text-sm text-slate-400">
        <div className="flex justify-between gap-4">
          <dt>Fenêtre</dt>
          <dd className="font-mono text-slate-200">{formatLaunchWindow(mission.launchAt)}</dd>
        </div>
        <div className="flex justify-between gap-4">
          <dt>Véhicule</dt>
          <dd className="text-slate-200">{vehicle?.name ?? "non assigné"}</dd>
        </div>
      </dl>
    </article>
  );
}
