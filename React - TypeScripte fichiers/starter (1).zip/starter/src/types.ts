export type VehicleStatus = "ready" | "maintenance" | "assigned" | "grounded";

export type MissionStatus =
  | "draft"
  | "scheduled"
  | "countdown"
  | "liftoff"
  | "ascent"
  | "orbit"
  | "docking"
  | "completed"
  | "aborted";

interface VehicleBase {
  readonly id: string;
  name: string;
  status: VehicleStatus;
}

export type LaunchVehicle =
  | (VehicleBase & {
      kind: "reusable-launcher";
      model: "Aquila";
      flightsCompleted: number;
    })
  | (VehicleBase & {
      kind: "heavy-launcher";
      model: "Titan";
      maxPayloadKg: number;
    })
  | (VehicleBase & {
      kind: "cargo-vehicle";
      model: "Hermes";
      dockingPort: "A" | "B" | "C";
    });

export interface Mission {
  id: string;
  codeName: string;
  vehicleId: string;
  launchAt: string;
  objective: string;
  status: MissionStatus;
}

export type AlertKind = "fuel" | "temperature" | "signal";
export type AlertSeverity = "warning" | "critical";

export interface GroundAlert {
  id: string;
  kind: AlertKind;
  severity: AlertSeverity;
  message: string;
  vehicleId: string;
}
