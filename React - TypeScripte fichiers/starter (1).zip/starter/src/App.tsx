import { useState } from "react";
import { SimulationBanner } from "./components/SimulationBanner";
import { AlertsPage } from "./pages/AlertsPage";
import { ControlPage } from "./pages/ControlPage";
import { FleetPage } from "./pages/FleetPage";
import { MissionsPage } from "./pages/MissionsPage";

type ModuleName = "fleet" | "missions" | "control" | "alerts";

const buttons: { id: ModuleName; label: string }[] = [
  { id: "fleet", label: "Flotte" },
  { id: "missions", label: "Missions" },
  { id: "control", label: "Contrôle" },
  { id: "alerts", label: "Alertes" },
];

export default function App() {
  const [module, setModule] = useState<ModuleName>("fleet");

  return (
    <div className="min-h-screen bg-slate-950">
      <SimulationBanner />
      <header className="border-b border-slate-800">
        <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-semibold tracking-wide text-white">
            ASTRAFORGE <span className="text-cyan-400">ORBITAL COMMAND</span>
          </p>
          <div className="flex flex-wrap gap-2">
            {buttons.map((button) => (
              <button
                key={button.id}
                type="button"
                onClick={() => setModule(button.id)}
                className={`rounded-md px-3 py-2 text-sm ${
                  module === button.id
                    ? "bg-cyan-500/15 text-cyan-200 ring-1 ring-cyan-400/40"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                {button.label}
              </button>
            ))}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8">
        {module === "fleet" ? <FleetPage /> : null}
        {module === "missions" ? <MissionsPage /> : null}
        {module === "control" ? <ControlPage /> : null}
        {module === "alerts" ? <AlertsPage /> : null}
      </main>
    </div>
  );
}
