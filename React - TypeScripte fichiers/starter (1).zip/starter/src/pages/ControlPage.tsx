import { missions } from "../data";
import { MissionBadge } from "../components/StatusBadge";

export function ControlPage() {
  return (
    <section>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-cyan-400">Centre de contrôle</p>
        <h1 className="mt-1 text-3xl font-semibold text-white">Salle de contrôle</h1>
        <p className="mt-2 max-w-2xl text-slate-300">
          Vue d&apos;ensemble des missions actives. La fiche détaillée et le poste
          <span className="font-mono"> /control/:missionId</span> arrivent aux TP suivants.
        </p>
      </header>
      <ul className="grid gap-3">
        {missions.map((mission) => (
          <li
            key={mission.id}
            className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/70 px-4 py-3"
          >
            <span className="font-medium text-white">{mission.codeName}</span>
            <MissionBadge status={mission.status} />
          </li>
        ))}
      </ul>
    </section>
  );
}
