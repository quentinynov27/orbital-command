import { alerts } from "../data";

const tone = {
  warning: "border-amber-500/30 bg-amber-500/10 text-amber-100",
  critical: "border-rose-500/30 bg-rose-500/10 text-rose-100",
};

export function AlertsPage() {
  return (
    <section>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-cyan-400">Journal d&apos;alertes</p>
        <h1 className="mt-1 text-3xl font-semibold text-white">Alertes sol</h1>
        <p className="mt-2 max-w-2xl text-slate-300">
          Anomalies pédagogiques. Aucune décision réelle de sécurité aéronautique n&apos;est
          représentée.
        </p>
      </header>
      {alerts.length === 0 ? (
        <p className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 text-slate-300">
          Aucune alerte en file. Le ciel pédagogique est calme.
        </p>
      ) : (
        <ul className="grid gap-3">
          {alerts.map((alert) => (
            <li
              key={alert.id}
              className={`rounded-xl border px-4 py-3 ${tone[alert.severity]}`}
            >
              <p className="text-xs uppercase tracking-wide">{alert.kind} · {alert.severity}</p>
              <p className="mt-1 text-sm">{alert.message}</p>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
