import { missions } from "../data";
import { MissionCard } from "../components/MissionCard";

export function MissionsPage() {
  return (
    <section>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-cyan-400">Module missions</p>
        <h1 className="mt-1 text-3xl font-semibold text-white">Planning de lancement</h1>
        <p className="mt-2 max-w-2xl text-slate-300">
          Dawn Watch, Heavy Lift 7 et Silent Harbor — fenêtres exprimées en heure de Paris.
        </p>
      </header>
      <div className="grid gap-4 lg:grid-cols-3">
        {missions.map((mission) => (
          <MissionCard key={mission.id} mission={mission} />
        ))}
      </div>
    </section>
  );
}
