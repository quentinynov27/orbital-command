import { vehicles } from "../data";
import { VehicleCard } from "../components/VehicleCard";

export function FleetPage() {
  return (
    <section>
      <header className="mb-6">
        <p className="text-xs uppercase tracking-[0.2em] text-cyan-400">Module flotte</p>
        <h1 className="mt-1 text-3xl font-semibold text-white">Registre de flotte</h1>
        <p className="mt-2 max-w-2xl text-slate-300">
          Cinq véhicules AstraForge. Les unités (kg, vols, ports) restent visibles à l&apos;écran.
        </p>
      </header>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {vehicles.map((vehicle) => (
          <VehicleCard key={vehicle.id} vehicle={vehicle} />
        ))}
      </div>
    </section>
  );
}
