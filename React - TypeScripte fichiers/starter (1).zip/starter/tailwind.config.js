/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        console: {
          bg: "#070b14",
          panel: "#0e1628",
          line: "#1e2a44",
        },
      },
    },
  },
  plugins: [],
};
