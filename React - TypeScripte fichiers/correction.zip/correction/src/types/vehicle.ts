export type VehicleStatus = "ready" | "maintenance" | "assigned" | "grounded";
export type DockingPort = "A" | "B" | "C";

export interface VehicleBase {
  readonly id: string;
  name: string;
  status: VehicleStatus;
}

export interface AquilaVehicle extends VehicleBase {
  kind: "reusable-launcher";
  model: "Aquila";
  flightsCompleted: number;
}

export interface TitanVehicle extends VehicleBase {
  kind: "heavy-launcher";
  model: "Titan";
  maxPayloadKg: number;
}

export interface HermesVehicle extends VehicleBase {
  kind: "cargo-vehicle";
  model: "Hermes";
  dockingPort: DockingPort;
}

export type LaunchVehicle = AquilaVehicle | TitanVehicle | HermesVehicle;
