import type { LaunchVehicle } from "../types/vehicle";

export const vehicles: LaunchVehicle[] = [
  {
    kind: "reusable-launcher",
    id: "AF-A01",
    name: "Aquila-1",
    model: "Aquila",
    status: "ready",
    flightsCompleted: 12,
  },
  {
    kind: "reusable-launcher",
    id: "AF-A02",
    name: "Aquila-2",
    model: "Aquila",
    status: "maintenance",
    flightsCompleted: 4,
  },
  {
    kind: "heavy-launcher",
    id: "AF-T01",
    name: "Titan Heavy",
    model: "Titan",
    status: "assigned",
    maxPayloadKg: 28000,
  },
  {
    kind: "cargo-vehicle",
    id: "AF-H01",
    name: "Hermes A",
    model: "Hermes",
    status: "ready",
    dockingPort: "B",
  },
  {
    kind: "cargo-vehicle",
    id: "AF-H02",
    name: "Hermes B",
    model: "Hermes",
    status: "grounded",
    dockingPort: "A",
  },
];
