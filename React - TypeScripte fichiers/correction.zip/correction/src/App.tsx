import { FleetGrid } from "./components/FleetGrid";
import { Metric } from "./components/Metric";
import { MetricGrid } from "./components/MetricGrid";
import { Panel } from "./components/Panel";
import { PanelHeader } from "./components/PanelHeader";
import { vehicles } from "./data/vehicles";

function App() {
  const readyCount = vehicles.filter((vehicle) => vehicle.status === "ready").length;
  const assignedCount = vehicles.filter((vehicle) => vehicle.status === "assigned").length;
  const maintenanceCount = vehicles.filter((vehicle) => vehicle.status === "maintenance").length;
  const groundedCount = vehicles.filter((vehicle) => vehicle.status === "grounded").length;
  const maintenanceVehicles = vehicles.filter((vehicle) => vehicle.status === "maintenance");

  return (
    <main className="app">
      <header className="app-header">
        <h1>Orbital Command</h1>
        <p>AstraForge Aerospace — registres de controle</p>
      </header>

      <Panel>
        <PanelHeader title="Flotte" subtitle={`${vehicles.length} vehicules`} />
        <FleetGrid vehicles={vehicles} />
      </Panel>

      <Panel>
        <PanelHeader title="Disponibilite" subtitle="Repartition par statut" />
        <MetricGrid>
          <Metric label="Prets" value={readyCount} unit="veh." />
          <Metric label="Affectes" value={assignedCount} unit="veh." />
          <Metric label="Maintenance" value={maintenanceCount} unit="veh." />
          <Metric label="Cloues au sol" value={groundedCount} unit="veh." />
        </MetricGrid>
      </Panel>

      <Panel>
        <PanelHeader
          title="Maintenance"
          subtitle={
            maintenanceVehicles.length === 0
              ? "Aucun vehicule en atelier"
              : `${maintenanceVehicles.length} vehicule(s) immobilise(s)`
          }
        />
        <FleetGrid vehicles={maintenanceVehicles} />
      </Panel>
    </main>
  );
}

export default App;
