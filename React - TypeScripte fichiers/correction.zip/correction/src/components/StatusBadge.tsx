import type { VehicleStatus } from "../types/vehicle";

interface StatusBadgeProps {
  status: VehicleStatus;
}

function assertNever(value: never): never {
  throw new Error(`Cas non traite: ${String(value)}`);
}

function getStatusLabel(status: VehicleStatus): string {
  switch (status) {
    case "ready":
      return "Pret";
    case "maintenance":
      return "Maintenance";
    case "assigned":
      return "Affecte";
    case "grounded":
      return "Cloue au sol";
    default:
      return assertNever(status);
  }
}

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    <span className={`status-badge status-${status}`}>{getStatusLabel(status)}</span>
  );
}
