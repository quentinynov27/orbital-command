import type { LaunchVehicle } from "../types/vehicle";
import { Metric } from "./Metric";
import { StatusBadge } from "./StatusBadge";

interface VehicleCardProps {
  vehicle: LaunchVehicle;
}

function assertNever(value: never): never {
  throw new Error(`Cas non traite: ${String(value)}`);
}

function getSpecificMetric(vehicle: LaunchVehicle): {
  label: string;
  value: string | number;
  unit: string;
} {
  switch (vehicle.kind) {
    case "reusable-launcher":
      return { label: "Vols realises", value: vehicle.flightsCompleted, unit: "vols" };
    case "heavy-launcher":
      return { label: "Charge utile max", value: vehicle.maxPayloadKg, unit: "kg" };
    case "cargo-vehicle":
      return { label: "Port d amarrage", value: vehicle.dockingPort, unit: "" };
    default:
      return assertNever(vehicle);
  }
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  const metric = getSpecificMetric(vehicle);
  return (
    <article className="vehicle-card">
      <h2>{vehicle.name}</h2>
      <p className="model">{vehicle.model}</p>
      <StatusBadge status={vehicle.status} />
      <Metric label={metric.label} value={metric.value} unit={metric.unit} />
    </article>
  );
}
