interface MetricProps {
  label: string;
  value: string | number;
  unit?: string;
}

export function Metric({ label, value, unit = "" }: MetricProps) {
  const suffix = unit ? ` ${unit}` : "";
  return (
    <div className="metric">
      <p className="metric-label">{label}</p>
      <p className="metric-value">
        {value}
        {suffix}
      </p>
    </div>
  );
}
