import type { ReactNode } from "react";

interface MetricGridProps {
  children: ReactNode;
}

export function MetricGrid({ children }: MetricGridProps) {
  return <div className="metric-grid">{children}</div>;
}
