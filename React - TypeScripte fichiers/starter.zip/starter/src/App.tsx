import { FleetGrid } from "./components/FleetGrid";
import { vehicles } from "./data/vehicles";

function App() {
  return (
    <main className="app">
      <header className="app-header">
        <h1>Orbital Command</h1>
        <p>AstraForge Aerospace — registre de flotte</p>
      </header>
      <FleetGrid vehicles={vehicles} />
    </main>
  );
}

export default App;
