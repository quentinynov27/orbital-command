import type { LaunchVehicle } from "../types/vehicle";
import { Metric } from "./Metric";
import { StatusBadge } from "./StatusBadge";

interface VehicleCardProps {
  vehicle: LaunchVehicle;
}

function assertNever(value: never): never {
  throw new Error(`Cas non traite: ${String(value)}`);
}

function getSpecificMetric(vehicle: LaunchVehicle): {
  label: string;
  value: string | number;
  unit: string;
} {
  switch (vehicle.kind) {
    //TODO
  }
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  const metric = getSpecificMetric(vehicle);
  return (
    //TODO
  );
}
