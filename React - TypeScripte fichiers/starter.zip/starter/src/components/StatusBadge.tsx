import type { VehicleStatus } from "../types/vehicle";

interface StatusBadgeProps {
  status: VehicleStatus;
}

function assertNever(value: never): never {
  throw new Error(`Cas non traite: ${String(value)}`);
}

function getStatusLabel(status: VehicleStatus): string {
  switch (status) {
//TODO
  }
}

export function StatusBadge({ status }: StatusBadgeProps) {
  return (
    //TODO
  );
}
