interface MetricProps {
  label: string;
  value: string | number;
  unit?: string;
}

export function Metric({ label, value, unit = "" }: MetricProps) {
  return (
//TODO
  );
}
